Rails.application.routes.draw do

  #devise_for :admin_users, ActiveAdmin::Devise.config
  ActiveAdmin.routes(self)
  root 'application#index'

  get :about, to: 'application#about'
  get :tools, to: 'application#tools'

  resources :departments, only: [:index, :show]
  resources :teams, only: [:show]

  namespace :saml do
    get :init
    post :consume
    get :logout
  end

end
