Airbrake.configure do |config|
  config.api_key = '6dc2feba52f35b0d4bbe53b4db0cc0e4'
  config.host    = 'errbit.suse.de'
  config.port    = 80
  config.secure  = config.port == 443
end
