require 'rails_helper'

describe OrgUnit do

  it { should validate_presence_of :name }

end
