class ConvertWorkforceidToString < ActiveRecord::Migration
  def change
    change_column :org_units, :leader_workforceid, :string
  end
end
