class AddParentUnitIdToOrgUnits < ActiveRecord::Migration
  def change
    add_column :org_units, :parent_unit_id, :integer
  end
end
