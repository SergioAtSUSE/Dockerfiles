class RenameLeaderId < ActiveRecord::Migration
  def change
    rename_column :org_units, :leader_id, :leader_workforce_id
  end
end
