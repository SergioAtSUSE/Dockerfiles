class CreateOrgUnits < ActiveRecord::Migration
  def change
    create_table :org_units do |t|
      t.string :name
      t.text :short_description
      t.text :description
      t.integer :leader_id
      t.string :type

      t.timestamps null: false
    end
  end
end
