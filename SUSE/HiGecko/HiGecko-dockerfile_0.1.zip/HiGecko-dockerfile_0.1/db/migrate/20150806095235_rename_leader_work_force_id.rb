class RenameLeaderWorkForceId < ActiveRecord::Migration
  def change
    rename_column :org_units, :leader_workforce_id, :leader_workforceid
  end
end
