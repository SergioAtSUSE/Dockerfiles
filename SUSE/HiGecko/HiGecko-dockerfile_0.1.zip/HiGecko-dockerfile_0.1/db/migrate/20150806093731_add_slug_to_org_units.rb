class AddSlugToOrgUnits < ActiveRecord::Migration
  def change
    add_column :org_units, :slug, :string
    add_index :org_units, :slug
    OrgUnit.find_each(&:save)
  end
end
