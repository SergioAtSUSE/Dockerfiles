# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

DEPARTMENTS = [{name: 'SUSE Linux Enterprise',
                leader_workforceid: 92229,
                teams: [{name: 'SLE Core', leader_workforceid: 92153},
                        {name: 'SLEPOS', leader_workforceid: 92071},
                        {name: 'Desktop', leader_workforceid: 50708},
                        {name: 'SysMgmt', leader_workforceid: 92070},
                        {name: 'China SLE', leader_workforceid: nil},
                        {name: 'PrjM / Arch', leader_workforceid: 92116}]},
               {name: 'SLE Extensions',
                leader_workforceid: 57786,
                teams: [{name: 'SLE Applications', leader_workforceid: 92035},
                        {name: 'Virtualization', leader_workforceid: '08872'},
                        {name: 'China Server', leader_workforceid: 97887}]},
               {name: 'Cloud & Systems Management',
                leader_workforceid: 92026,
                teams: [{name: 'SUSE Manager', leader_workforceid: 85464},
                        {name: 'SCC', leader_workforceid: 92282},
                        {name: 'UX / UI', leader_workforceid: 92442},
                        {name: 'Machinery', leader_workforceid: 92388},
                        {name: 'Cloud Mgmt', leader_workforceid: 92012}]},
               {name: 'Labs',
                leader_workforceid: 92474,
                teams: [{name: 'Kernel Storage', leader_workforceid: 92497},
                        {name: 'Kernel Core', leader_workforceid: 87605},
                        {name: 'Tool Chain', leader_workforceid: 92264},
                        {name: 'Samba', leader_workforceid: 89262},
                        {name: 'HW Enablement TPE', leader_workforceid: 93076},
                        {name: 'Hardware Enablement', leader_workforceid: 85539},
                        {name: 'Performance', leader_workforceid: 94996}]},
               {name: 'QA',
                leader_workforceid: 92276, 
                teams: [{name: 'QA NUE', leader_workforceid: nil},
                        {name: 'QA APAC I', leader_workforceid: 91913},
                        {name: 'QA APAC II', leader_workforceid: 90666},
                        {name: 'QA PRG', leader_workforceid: 98783}]},
               {name: 'L3 / Maintenance',
                leader_workforceid: 92180, 
                teams: [{name: 'L3 Team 1', leader_workforceid: 86729},
                        {name: 'L3 Team 2', leader_workforceid: 90820},
                        {name: 'Maintenance QA NUE', leader_workforceid: 92353},
                        {name: 'Maintenance QA PRG', leader_workforceid: 98783},
                        {name: 'Maintenance QA China', leader_workforceid: 94338},
                        {name: 'Maintenance Security', leader_workforceid: 92101},
                        {name: 'Packaging', leader_workforceid: 95670}]},
               {name: 'Engineering Services', 
                leader_workforceid: 92025,
                teams: [{name: 'Services', leader_workforceid: 92358},
                        {name: 'Documentation', leader_workforceid: 98836},
                        {name: 'DevOPS', leader_workforceid: 52385}]}]

DEPARTMENTS.each do |department_data|
  department = Department.find_or_create_by(name: department_data[:name])
  department.update_attributes(leader_workforceid: department_data[:leader_workforceid]) unless department.leader_workforceid
  puts "Added department #{department.name}" if department.new_record?
  department_data[:teams].each do |team_data|
    team = Team.find_or_create_by(name: team_data[:name])
    team.update_attributes(leader_workforceid: team_data[:leader_workforceid]) unless team.leader_workforceid
    department.teams << team
    puts "Added team #{team.name} to department #{department.name}" if team.new_record?
  end
end
