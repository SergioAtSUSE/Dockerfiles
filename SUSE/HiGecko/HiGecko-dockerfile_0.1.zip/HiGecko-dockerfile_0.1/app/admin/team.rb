ActiveAdmin.register Team do

  controller do
    def find_resource
      scoped_collection.friendly.find(params[:id])
    end
  end

  config.batch_actions = false

  permit_params :name, :short_description, :description, :leader_workforceid, :parent_unit_id, :slug

  index do
    selectable_column
    id_column
    column :name
    column :short_description
    column :description
    column 'Department' do |t|
      t.department.name
    end
    column 'TeamLead', :leader_workforceid
    actions
  end

  filter :name
  filter :type
end
