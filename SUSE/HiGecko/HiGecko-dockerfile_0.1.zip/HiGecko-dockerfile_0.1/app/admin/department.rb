ActiveAdmin.register Department do

  controller do
    def find_resource
      scoped_collection.friendly.find(params[:id])
    end
  end

  config.batch_actions = false

  permit_params :name, :short_description, :description, :leader_workforceid

  index do
    selectable_column
    id_column
    column :name
    column :short_description
    column :description
    column :leader_workforceid
    actions
  end

  filter :name
  filter :type
end
