class TeamsController < ApplicationController

  def show
    @team = Team.friendly.find(params[:id])
    render 'org_units/_org_unit', locals: { org_unit: @team }
  end

end
