class DepartmentsController < ApplicationController

  def index
    @departments = OrgUnit.departments
  end

  def show
    @department = OrgUnit.friendly.find(params[:id])
    render 'org_units/_org_unit', locals: { org_unit: @department }
  end

end
