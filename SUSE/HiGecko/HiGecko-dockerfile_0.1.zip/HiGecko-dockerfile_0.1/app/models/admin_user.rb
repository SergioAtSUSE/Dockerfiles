class AdminUser < ActiveRecord::Base
  
  class << self

    def find_or_create_for_saml(data)
      user = self.where('lower(username) = ?', data[:username].downcase).first || self.new
      user.update_attributes!(data.merge({ current_sign_in_at: Time.zone.now, last_sign_in_at: user.current_sign_in_at }))
      user.increment!(:sign_in_count)
      user
    end

  end
   
end
