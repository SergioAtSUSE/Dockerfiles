class Crawler

  class LdapUser < OpenStruct

    def image
      Dragonfly.app.fetch_url(chosen_photo_url)
    end

    private

    def chosen_photo_url
      if (floor_pic = self.try(:floor_user).try(:[], 'pic'))
        URI.join(Rails.application.secrets.staff_microservice_url, floor_pic).to_s
      else
        self.photo
      end
    end
  end

  class << self

    def tree
      root = cached_users.find{|x| x.id == x.managerid }
      @tree ||= Tree::TreeNode.new(root.name, root)
    end

    def cache_key
      'ldap_users_cache'
    end

    def ldap_users
      users = JSON.parse(RestClient.get("#{staff_microserver_base}/api/users.json"))
      users.map{|u| LdapUser.new(u)}
    end

    def cached_users
      Rails.cache.fetch cache_key, expires_in: 4.hours do
        ldap_users
      end
    end

    def traverse_tree
      tree.each do |node|
        if node.has_children?
          return tree
        end
        cached_users.select{|x| x.id != x.managerid && x.managerid == node.content.id}.each do |subordinate|
          node << Tree::TreeNode.new(subordinate.name, subordinate)
        end
      end
    end

    private

    def staff_microserver_base
      @staff_microserver_base ||= Rails.application.secrets.staff_microservice_url
    end

  end

end
