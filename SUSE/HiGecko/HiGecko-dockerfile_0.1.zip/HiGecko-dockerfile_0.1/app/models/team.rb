class Team < OrgUnit

  belongs_to :department, foreign_key: :parent_unit_id
  validates :department, :leader_workforceid, presence: true

end
