class OrgUnit < ActiveRecord::Base
  extend FriendlyId

  has_paper_trail
  friendly_id :name, use: :slugged

  scope :departments, -> { where(type: 'Department') }
  scope :teams, -> { where(type: 'Team') }

  validates :name, presence: true

  def self.types
    %w(Department Team)
  end

  def slug_candidates
    [
      :name,
      [:name, :id],
    ]
  end

  def members
    Crawler::LdapUserDecorator.decorate_collection(Crawler.cached_users.select{|u| u.managerworkforceid == leader_workforceid.to_s})
  end

  def lead
    Crawler::LdapUserDecorator.decorate(Crawler.cached_users.find(&lead_selector))
  end

  def lead_selector
    lambda do |user|
      user.workforceid == leader_workforceid.to_s
    end
  end

end
