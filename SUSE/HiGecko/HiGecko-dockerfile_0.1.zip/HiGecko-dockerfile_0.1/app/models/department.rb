class Department < OrgUnit

  has_many :teams, class_name: 'OrgUnit', foreign_key: :parent_unit_id

end
