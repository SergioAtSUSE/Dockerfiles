class Crawler::LdapUserDecorator < Draper::Decorator
  delegate_all

  def phone
    object.phone.gsub(/\s+/,'').gsub(/\+4991174053/, '') rescue nil
  end

  def title
    object.title.empty? ? 'no title' : object.title
  end

end

