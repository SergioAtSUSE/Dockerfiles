//= require jquery
//= require jquery_ujs
//= require turbolinks
//= require twitter/bootstrap
//= require_tree .

$(window).on('load', resizeLayout)
$(document).on('ready page:change', resizeLayout)
$(window).on('resize', resizeLayout)

function resizeLayout() {
  $(".description-box").removeAttr('style')
  var sectionHeight = $("section").outerHeight(),
      descriptionBoxHeight = $(".description-box").height()
  $(".sidebar").css("height",sectionHeight)
  if (descriptionBoxHeight < sectionHeight) {
    $(".description-box").css("height", sectionHeight - 159)
  }
};

function showtext(obj) {
  $(".hide_text").hide()
  $("#"+obj).toggle()
  $(window).scrollTop(0)
  resizeLayout()
};

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
