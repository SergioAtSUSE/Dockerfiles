## How to change this site

### Organizational Units (Departments and Teams)

Seed data is the representation of [Organization Chart](https://w3.nue.suse.com/~mreichel/)
Any further changes to organization structure are done via admin interface located at 
 
[http://onboarding.suse.com/admin](http://onboarding.suse.com/admin)

As the Team Lead you can obtain access from your department lead. As the department lead you obtain your credentials from
Mihnea Istinie.

Having credentials to access the system will allow you to:

* Change your team/department description
* Change `workforceid` of a lead for a specific department or team
* Move team to another department
* Change link slug for the team (keep in mind that it will break existing references) 

Structure of organization does include only R&D.

Keep in mind that based on the teamlead `workforceid` the whole org unit is assembled - system lookup that workforceid and
display all subordinates of that person.

### User data

User data is stored in the cache which is repopulated every 4 hours. So after changes are done in external systems
that will take some time to show them here.

If you want to change appearance of your personal data, please keep in mind that 
your phone and title are taken from eDirectory where only HR representative can make changes to the title, but
through Innerweb you also can change your own phone. Phone is converted to internal phone number via 

```
gsub(/\+49\s*911\s*74053/, '')
```

* Information about room taken from floor.suse.de
* Email from eDirectory (Novell Ldap)
* Avatar from floor.suse.de
* Your manager is determined via `Manager's Workforce ID` field in eDirectory


### Feature requests

Please drop an issue or better PR on [GitHub](https://github.com/SUSE/HiGecko) if you want to add some new feature
